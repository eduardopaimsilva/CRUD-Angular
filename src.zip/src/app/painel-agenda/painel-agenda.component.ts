import { Component, OnInit } from '@angular/core';
import { AgendaService } from '../agenda.service';

@Component({
  selector: 'app-painel-agenda',
  templateUrl: './painel-agenda.component.html',
  styleUrls: ['./painel-agenda.component.css']
})
export class PainelAgendaComponent implements OnInit {
  
  agenda = [];
  contato: any = {};
  operacao: boolean = true;

  constructor(private service: AgendaService) { }

  ngOnInit(): void {
    this.buscar();
  }
    buscar(){
      this.service.
      listar().
      subscribe(resposta => this.agenda = <any>resposta);

  }
  adicionar(){
    this.service.salvar(this.contato).subscribe(
      ()=> {
      this.contato = {}; //limpar os campos
      this.buscar(); //atualizar a lista de agenda
  },
  () =>{
    alert("Ocorreu um erro inesperado! Contate o adminstrador!");
  }); 
}
 excluir(id: number){
  this.service.excluir(id).subscribe(()=> {
    this.buscar();
    alert("Contato excluído com sucesso!!!");
  },
  ()=> alert("Não foi possivel excuir!")
  );
 }
 inserirOuAtualizar(){
  if(this.operacao == true) {
    this.adicionar();
  }else {
    this.atualizar();
    this.operacao = true;
  }
 }
 editar(cont: any) {
  this.contato = {id: cont.id, nome: cont.nome, telefone: cont.telefone};
  this.operacao = false;
 }
 atualizar() {
  this.service.atualizar(this.contato).subscribe(() => {
    this.contato = {};
    this.buscar();
  });
 }

}
