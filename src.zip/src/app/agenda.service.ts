import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

/*
Por que temos classe de Serviços?
A ideia é que separe as responsabilidades:
 - css = fica toda parte de estilização;
 - html = fica todo o corpo do html;
 - ts fica toda parte lógica (rega de négocio)
 - service (ts) = guardar a logica das requisição para backend
 - 
  Rotas
  Comunicação é estabelicida atráves de protocolos. HTTP
  GET - 'http://localhost:3000/agenda';  trazer dados do servidor
          'http://localhost:3000/{URI}';
  POST - 'http://localhost:3000/agenda';  Gravar dados dentro do servidor
  GET - 'http://localhost:3000/agenda/1 Trazer o dados de ID (identificador) de valor 1
  PUT - 'http://localhost:3000/agenda/1  Atualizar informção de um determinado conteúdo
  DELETE - 'http://localhost:3000/agenda/1  Deletar um determinado conteudo do servidor

*/
export class AgendaService {

  url = 'http://localhost:3000/agenda';
  constructor(private http:HttpClient) { }
  listar(){
    return this.http.get(this.url);
  }
  salvar(contato: any){
    return this.http.post(this.url, contato);
  }
  excluir(id: number){
    return this.http.delete(this.url+'/'+id);
  }
  atualizar(contato: any){
    return this.http.put(this.url+'/'+contato.id, contato);
  }
}